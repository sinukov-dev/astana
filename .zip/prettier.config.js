module.exports = {
    singleQuote: true,
    trailingComma: 'all',
    arrowParens: 'always',
    printWidth: 110,
    semi: true,
};
